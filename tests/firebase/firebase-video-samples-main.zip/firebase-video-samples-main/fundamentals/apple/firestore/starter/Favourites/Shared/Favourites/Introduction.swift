import Foundation
import SwiftUI

import FirebaseCore
import FirebaseFirestore

extension Introduction {
  func createDocument() {
  }
  
  func updateDocument() {
  }
  
  func updateDocument2() {
  }
  
  func addDocumentAsync() {
  }
  
  func fetchDocument() {
  }

  func fetchDocumentAsync() {
  }
}
