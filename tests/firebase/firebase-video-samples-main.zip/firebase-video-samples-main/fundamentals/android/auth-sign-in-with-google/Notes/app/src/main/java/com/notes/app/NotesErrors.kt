package com.notes.app

const val ERROR_TAG = "NOTES APP ERROR"
const val UNEXPECTED_CREDENTIAL = "Unexpected type of credential"