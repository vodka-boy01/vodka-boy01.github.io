package com.notes.app.model

data class User(
    val id: String = ""
)